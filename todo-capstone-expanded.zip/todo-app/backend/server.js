const express = require('express');
const bodyParser = require('body-parser');
const { DynamoDBClient, PutItemCommand, ScanCommand } = require('@aws-sdk/client-dynamodb');
const app = express();
app.use(bodyParser.json());
const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });

app.post('/api/todo', async (req, res) => {
  const { id, text } = req.body;
  try {
    await client.send(new PutItemCommand({
      TableName: process.env.TODOS_TABLE || 'todos',
      Item: { id: { S: id }, text: { S: text } }
    }));
    res.status(201).send({ id, text });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'dynamo error' });
  }
});

app.get('/api/todo', async (req, res) => {
  try {
    const out = await client.send(new ScanCommand({ TableName: process.env.TODOS_TABLE || 'todos' }));
    res.send(out.Items || []);
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: 'dynamo error' });
  }
});

app.listen(3000, ()=>console.log('API listening on 3000'));
