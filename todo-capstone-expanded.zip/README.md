# Todo Capstone Starter

This archive contains a minimal, opinionated starter for the capstone:
Automating Deployment of a Dockerized ToDo App on AWS EKS Using GitOps and ArgoCD.

Included:
- todo-app/ (frontend + backend)
- gitops-manifests/ (k8s manifests)
- infrastructure/terraform/ (minimal terraform for ECR + DynamoDB)
- .circleci/config.yml (example CI pipeline)

IMPORTANT: These are example files to get you started. Replace placeholders like AWS_ACCOUNT_ID, AWS_DEFAULT_REGION, PROJECT_PREFIX, and git repo URLs before running in CI or Terraform.

Suggested next steps:
1. Initialize terraform: terraform init; terraform apply
2. Create ECR repos (or let terraform create them) and push images (CircleCI will do this)
3. Provision EKS (use terraform eks module or eksctl)
4. Install ArgoCD and point it to gitops-manifests repo
5. Configure CircleCI project env vars and SSH keys for pushing to manifests repo

