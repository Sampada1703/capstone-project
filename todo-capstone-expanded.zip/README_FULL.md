TODO Capstone - Expanded Starter

This expanded starter includes:
- todo-app/ (frontend + backend example code)
- gitops-manifests/ (k8s manifests for frontend & backend)
- infrastructure/terraform/ (ECR, DynamoDB, VPC, and EKS module)
- argocd/ (instructions + ArgoCD Application manifests)
- .github/workflows/ci-cd.yml (GitHub Actions pipeline)

NOTES & Next steps:
1. Replace placeholders in files (AWS account id, ECR URLs, GitHub repo URLs).
2. Initialize Terraform: terraform init
3. Run: terraform apply (ensure AWS creds configured)
4. After EKS is up, install ArgoCD and create the Application manifests (kubectl apply -f argocd/*.yaml)
5. Push images to ECR (use GitHub Actions or local docker push)
6. Verify ArgoCD syncs and application becomes healthy
