This Terraform example creates ECR repositories and a DynamoDB table. For an EKS cluster, use the terraform-aws-modules/eks/aws module or eksctl. This file is a minimal starting point.
