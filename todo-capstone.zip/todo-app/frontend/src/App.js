import React, {useState, useEffect} from 'react';
import './App.css';

function App(){
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState('');
  useEffect(()=> {
    fetch('/api/todo').then(r=>r.json()).then(d=> setTodos(d || []));
  }, []);
  const add = async ()=> {
    const id = Date.now().toString();
    await fetch('/api/todo', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id, text})
    });
    setTodos([...todos, {id, text}]);
    setText('');
  };
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>Todo App (Demo)</h1>
      <div>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="New todo" />
        <button onClick={add}>Add</button>
      </div>
      <ul>
        {todos.map((t,i)=><li key={i}>{t.text ? t.text.S : JSON.stringify(t)}</li>)}
      </ul>
    </div>
  );
}

export default App;
